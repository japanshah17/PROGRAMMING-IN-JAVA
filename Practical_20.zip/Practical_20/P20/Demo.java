public class Demo{
	public int publicvar = 10;
	private int privatvar = 20;
	protected int protectedvar = 30;
	int defaultvar = 40;
	public void showall(){
		System.out.println("Same Class");
		System.out.println("publicvar is : " +publicvar +" " +"privatvar is : " +privatvar +" "+"protectedvar is : " +protectedvar +" " +"defaultvar is : " +defaultvar);
	}
	public static void main(String args []){
		Demo Dobj = new Demo();
		Dobj.showall();
	}
	
}