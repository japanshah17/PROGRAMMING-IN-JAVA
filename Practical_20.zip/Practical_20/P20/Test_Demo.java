public class Test_Demo{
	public static void main(String args []){
		System.out.println("Non-Subclass Same Package");
		Demo Tobj = new Demo();
		System.out.println("publicvar is : " +Tobj.publicvar );
		//System.out.println("privatvar is : " +Tobj.privatvar);//cannot access private member outside class
		System.out.println("protectedvar is : " +Tobj.protectedvar);
		System.out.println("defaultvar is : " +Tobj.defaultvar);
	}
	
}