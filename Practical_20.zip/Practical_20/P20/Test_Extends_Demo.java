public class Test_Extends_Demo extends Demo{
	public static void main(String args []){
		System.out.println("Subclass Same Package");
		Demo Tobj = new Demo();
		System.out.println("publicvar is : " +Tobj.publicvar );
		//System.out.println("privatvar is : " +Tobj.privatvar);//cannot access private member outside class
		System.out.println("protectedvar is : " +Tobj.protectedvar);
		System.out.println("defaultvar is : " +Tobj.defaultvar);
	}
	
}