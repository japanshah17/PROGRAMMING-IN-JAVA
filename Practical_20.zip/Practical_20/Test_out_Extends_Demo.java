import P20.Demo;
class Test extends Demo{
	void show(){
		System.out.println("Subclass Another package");
		System.out.println("protectedvar is : " +protectedvar);
	}
}
public class Test_Out_Extends_Demo{
	public static void main(String args []){
		Demo Tobj = new Demo();
		Test o = new Test();
		o.show();
		System.out.println("publicvar is : " +Tobj.publicvar );
		//System.out.println("privatvar is : " +Tobj.privatvar);
		//System.out.println("defaultvar is : " +Tobj.defaultvar);
	}
	
}