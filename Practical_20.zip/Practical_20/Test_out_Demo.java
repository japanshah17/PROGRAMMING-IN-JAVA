import P20.Demo;
public class Test_Out_Demo{
	public static void main(String args []){
		System.out.println("Non-Subclass Another Package");
		Demo Tobj = new Demo();
		System.out.println("publicvar is : " +Tobj.publicvar );
		//System.out.println("privatvar is : " +Tobj.privatvar);
		//System.out.println("protectedvar is : " +Tobj.protectedvar);
		//System.out.println("defaultvar is : " +Tobj.defaultvar);
	}
	
}